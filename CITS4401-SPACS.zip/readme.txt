# CITS4401-SPACS
Practical Assignment for CITS4401.
Liam Jones, 10523527


# How to use
Unzip project zip.
Recommend use install virtualenv to not clutter actual system.
With virtualenv installed, run 'virtualenv venv' in folder with project, then
run 'source venv/bin/activate' on Unix. Note: Should be running python 3.4.
Then run 'python application.py' and browse to http://localhost:8080 in your browser.

# Users
Username, password
'PoolOwner1', 'a'
'PoolOwner2', 'b'
'PoolShopAdmin1', 'c',
'SPACSAdmin1', 'd'